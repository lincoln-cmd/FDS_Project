from django.contrib import admin
from .models import FraudData

# Register your models here.

admin.site.register(FraudData)